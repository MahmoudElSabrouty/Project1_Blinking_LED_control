# Project1_Blinking_LED_control

TODOs:

1- Implement generic Driver Clk Gating Function>
use static void enableGptClkGating(const Gpt_ConfigType * ConfigPtr) as reference

Fixes:
- Enable ClkGating for Gpt Driver